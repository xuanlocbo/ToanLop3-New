MỘC NHIÊN TOÁN 3 — BƯỚC 1: BỘ TÀI NGUYÊN ĐỒ HỌA
Nguồn: xuanlocbo/ToanLop3-New@8320b128928deb6e04fd40099a1280b3bb1740fc (nhánh v1.2.1-ui).
5 WebP gốc được giữ nguyên theo blob SHA; các tài nguyên còn lại là SVG riêng, bố cục có thể xem trong catalog.html.
Mở catalog.html sau khi giải nén ZIP để xem toàn bộ tài nguyên.
218 hình ảnh/bố cục; 959 bản ghi ánh xạ, 19 màn chơi. Ánh xạ từ khóa là gợi ý và cần kiểm tra ngữ cảnh.
Bước 2: chuyển SVG thành WebP/PNG hoặc Android VectorDrawable phù hợp, hoặc dùng Android Canvas, giữ nguyên 5 WebP gốc. Không dùng HTML/WebView cho app. Bố cục chỉ là mẫu, triển khai native với text động; kiểm tra từng hình và cách dùng.
Không thay nội dung, thứ tự bài, số liệu, đáp án, âm thanh, tiến trình, điều kiện mở khóa, giải thưởng, va chạm trò chơi. Không dùng hình mẫu để thay số đo, số lượng hay sơ đồ chính xác.
Chưa xác nhận run ID #51 hoặc đối chiếu pixel với ảnh thiết kế được duyệt trước đây; đây là bộ ảnh dựa trên mã nguồn v1.2.1-ui và 12 tệp bài học.
Bước 1 không chỉnh mã ứng dụng, không build APK. Bước 2 và 3 còn phải tích hợp, kiểm thử và xuất APK.
